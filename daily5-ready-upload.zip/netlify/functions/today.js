// netlify/functions/today.js
import { getStore } from '@netlify/blobs';

function yyyymmdd(d = new Date(), tz = 'America/New_York') {
  const p = new Intl.DateTimeFormat('en-CA', {
    timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(d).reduce((a,p)=> (a[p.type]=p.value, a), {});
  return `${p.year}${p.month}${p.day}`;
}

export const handler = async () => {
  try {
    const store = getStore('daily5');
    const dayStr = yyyymmdd();
    const key = `daily-${dayStr}.json`;

    const cached = await store.get(key);
    if (cached) return new Response(cached, { headers: { 'content-type': 'application/json' }});

    const res = await fetch('https://opentdb.com/api.php?amount=5&type=multiple');
    if (!res.ok) {
      const fallback = { day: dayStr, questions: [
        { text: "What is the capital of France?", options: ["Paris","Rome","Madrid","Berlin"], correct: 0 },
        { text: "Who painted the Mona Lisa?", options: ["Leonardo da Vinci","Michelangelo","Raphael","Donatello"], correct: 0 },
        { text: "Which planet is known as the Red Planet?", options: ["Mars","Jupiter","Venus","Saturn"], correct: 0 },
        { text: "What is H2O commonly known as?", options: ["Water","Hydrogen","Oxygen","Salt"], correct: 0 },
        { text: "What is 9 × 9?", options: ["81","72","99","64"], correct: 0 }
      ]};
      return new Response(JSON.stringify(fallback), { headers: { 'content-type': 'application/json' } });
    }
    const data = await res.json();
    const questions = (data.results || []).map(q => ({
      text: q.question,
      options: [q.correct_answer, ...q.incorrect_answers],
      correct: 0,
      category: q.category || '',
      difficulty: q.difficulty || ''
    }));
    const payload = JSON.stringify({ day: dayStr, questions });
    await store.set(key, payload, { metadata: { day: dayStr }, ttl: 60*60*24*3 });
    return new Response(payload, { headers: { 'content-type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({ error: 'internal', details: String(e) }), { status: 500 });
  }
};
